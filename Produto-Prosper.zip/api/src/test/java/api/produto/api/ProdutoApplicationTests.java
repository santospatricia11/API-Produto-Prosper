package api.produto.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
